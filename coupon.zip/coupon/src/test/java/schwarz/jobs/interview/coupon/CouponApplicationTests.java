package schwarz.jobs.interview.coupon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponApplicationTests {

	@Test
	void contextLoads() {
	}

}
